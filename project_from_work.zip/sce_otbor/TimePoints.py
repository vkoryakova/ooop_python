from PyQt6.QtWidgets import QMainWindow

from window_5tp import Ui_time_points
import threading
import sqlite3

connection = sqlite3.connect("otbor.db")
cursor = connection.cursor()


class TimePoints(QMainWindow):
    def __init__(self, main_app):
        super().__init__()
        self.main_app = main_app
        self.ui = Ui_time_points()
        self.ui.setupUi(self)
        self.temp_values = {'time_points': [0] * 10}

        self.ui.pushButton_15.clicked.connect(self.open_menu)
        self.ui.pushButton_16.clicked.connect(self.save)
        self.ui.pushButton_31.clicked.connect(self.start)

        self.labels = [self.ui.label, self.ui.label_2, self.ui.label_3, self.ui.label_4,
                       self.ui.label_5, self.ui.label_6, self.ui.label_7, self.ui.label_11, self.ui.label_12,
                       self.ui.label_13]
        self.inc_buttons = [self.ui.pushButton_9, self.ui.pushButton_10, self.ui.pushButton_13,
                            self.ui.pushButton_8, self.ui.pushButton_11, self.ui.pushButton_14,
                            self.ui.pushButton_12, self.ui.pushButton_18, self.ui.pushButton_20, self.ui.pushButton_22]
        self.dec_buttons = [self.ui.pushButton, self.ui.pushButton_3, self.ui.pushButton_5,
                            self.ui.pushButton_2, self.ui.pushButton_4, self.ui.pushButton_6,
                            self.ui.pushButton_7, self.ui.pushButton_17, self.ui.pushButton_19, self.ui.pushButton_21]

        for i in range(10):
            self.inc_buttons[i].clicked.connect(lambda _, idx=i: self.change_time_point(idx, 1))
            self.dec_buttons[i].clicked.connect(lambda _, idx=i: self.change_time_point(idx, -1))

        self.update_labels()

    def change_time_point(self, index, delta):
        self.temp_values['time_points'][index] += delta

        for i in range(1, len(self.temp_values['time_points'])):
            if self.temp_values['time_points'][i] <= self.temp_values['time_points'][i - 1]:
                self.temp_values['time_points'][i] = self.temp_values['time_points'][i - 1] + 1

        # Если последний элемент равен 119, ограничиваем предыдущие
        if self.temp_values['time_points'][-1] >= 119:
            self.temp_values['time_points'][-1] = 119
            for i in range(len(self.temp_values['time_points']) - 2, -1, -1):
                self.temp_values['time_points'][i] = min(self.temp_values['time_points'][i],
                                                         118 - (len(self.temp_values['time_points']) - 2 - i))

        self.update_labels()

    def update_labels(self):
        for i, label in enumerate(self.labels):
            label.setText(f"{i + 1} Точка: {self.temp_values['time_points'][i]} мин")

        self.update_button_states()

    def update_button_states(self):
        if self.temp_values['time_points'][0] == 0:
            # Блокируем все кнопки, кроме той, которая увеличивает первый элемент
            for button in self.inc_buttons[1:] + self.dec_buttons:
                button.setEnabled(False)
            self.inc_buttons[0].setEnabled(True)
        else:
            max_value_reached = self.temp_values['time_points'][-1] >= 119
            for i, button in enumerate(self.inc_buttons[:-1]):
                button.setEnabled(not max_value_reached)

            # Первый элемент не может быть уменьшен ниже нуля
            self.dec_buttons[0].setEnabled(self.temp_values['time_points'][0] > 0)

            # Каждый элемент должен быть больше предыдущего
            for i in range(1, len(self.dec_buttons)):
                self.dec_buttons[i].setEnabled(
                    self.temp_values['time_points'][i] > (self.temp_values['time_points'][i - 1] + 1))
            self.inc_buttons[-1].setEnabled(self.temp_values['time_points'][-1] < 120)

    def showEvent(self, event):
        self.temp_values = {'time_points': [0] * 10}
        self.update_labels()

    def save(self):
        self.save_to_db()
        self.open_menu()

    def save_to_db(self):
        cursor.execute('''
                    INSERT INTO time_points (one_point, two_point, three_point, four_point, five_point, six_point, 
                    seven_point, eight_point, nine_point, ten_point) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', tuple(self.temp_values['time_points']))
        connection.commit()

    def save_params_to_file(self):
        cursor.execute('''
            SELECT time_points.one_point, time_points.two_point, 
            time_points.three_point, time_points.four_point, time_points.five_point, time_points.six_point,
            time_points.seven_point, time_points.eight_point, time_points.nine_point, time_points.ten_point
            FROM time_points
            ORDER BY time_points.id DESC LIMIT 1;
        ''', )
        param = cursor.fetchone()
        connection.close()

        if param:
            with open("saved_parameters.txt", "w") as file:
                file.write("\n".join(map(str, param)))

    def start_otbor(self):
        threading.Thread(target=self.main_app.launch_script, args=[
            "main_start_otbor_with_k_l2.py"]).start() #скрипт запуска отборочных моторов на первой плате

    def start(self):
        self.save_to_db()
        self.save_params_to_file()
        self.start_otbor()
        self.open_menu()

    def closeEvent(self, event):
        connection.close()
        event.accept()

    def open_menu(self):
        self.main_app.stack.setCurrentIndex(0)
