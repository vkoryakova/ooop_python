import subprocess
from PyQt6.QtWidgets import QApplication, QMainWindow, QStackedWidget
from StartMenu import StartMenu
from LoadSavedParameters import LoadSavedParameters
from TimePoints import TimePoints
from ProcessTimeOtbor import ProcessOtbor
import sys


class Application(QApplication):
    def __init__(self, args):
        super().__init__(args)
        self.main_window = QMainWindow()
        self.stack = QStackedWidget()
        self.temp_values = {'time_points': [0] * 10}

        self.first_window = StartMenu(self)
        self.second_window = LoadSavedParameters(self)
        self.third_window = TimePoints(self)
        self.fourth_window = ProcessOtbor(self)

        self.stack.addWidget(self.first_window)
        self.stack.addWidget(self.second_window)
        self.stack.addWidget(self.third_window)
        self.stack.addWidget(self.fourth_window)

        self.main_window.setCentralWidget(self.stack)
        self.main_window.showFullScreen()

    def launch_script(self, script_path):
        try:
            process = subprocess.Popen(["python3", script_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                       text=True)
            stdout, stderr = process.communicate()

            if process.returncode == 0:
                print(f"Output from {script_path}: {stdout}")
            else:
                print(f"Script {script_path} exited with error")
                print(f"stderr: {stderr}")

        except FileNotFoundError as e:
            print(f"File not found: {e}")
        except Exception as e:
            print(f"An unexpected error occurred while running {script_path}: {e}")


if __name__ == '__main__':
    app = Application(sys.argv)
    sys.exit(app.exec())
