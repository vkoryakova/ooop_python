from window_2s import Ui_second_window

from PyQt6.QtWidgets import QMainWindow
from PyQt6.QtCore import QTimer, QDateTime
import threading


class StartMenu(QMainWindow):
    def __init__(self, main_app):
        super().__init__()
        self.main_app = main_app
        self.ui = Ui_second_window()
        self.ui.setupUi(self)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)
        self.ui.pushButton_load.clicked.connect(self.open_load_parameters)
        self.ui.pushButton_create.clicked.connect(self.open_create_parameters)
        self.ui.pushButton.clicked.connect(self.promivka)
        self.ui.pushButton_2.clicked.connect(self.shotdown)

        self.update_time()

    def update_time(self):
        # Получение текущей даты и времени
        current_datetime = QDateTime.currentDateTime()
        formatted_datetime = current_datetime.toString("yyyy-MM-dd HH:mm:ss")
        self.ui.label_3.setText(formatted_datetime)

    def open_load_parameters(self):
        self.main_app.stack.setCurrentIndex(1)

    def open_create_parameters(self):
        self.main_app.stack.setCurrentIndex(2)

    def promivka(self):
        threading.Thread(target=self.main_app.launch_script, args=[
            "ssh_promivka_motors.py"]).start() #скрипт промывки трубок на второй плате, обращаемся к нему с помщью ssh

    def shotdown(self):
        threading.Thread(target=self.main_app.launch_script, args=[
            "ssh_bath_shotdown.py"]).start() #скрипт остановки процесса работы моторов на второй плате, обращаемся к нему с помщью ssh