from PyQt6.QtGui import QCursor, QFont
from PyQt6.QtWidgets import QMainWindow, QMessageBox, QPushButton, QMenu, \
    QListWidgetItem, QDialog
from window_2_1saved import Ui_saved_parametrs_window
import sqlite3
import threading

connection = sqlite3.connect("otbor.db")
cursor = connection.cursor()


class LoadSavedParameters(QMainWindow):
    def __init__(self, main_app):
        super().__init__()
        self.main_app = main_app
        self.ui = Ui_saved_parametrs_window()
        self.ui.setupUi(self)
        self.ui.pushButton_back.clicked.connect(self.open_start_menu)
        self.ui.listWidget.itemClicked.connect(self.on_param_click)
        self.loadParamData()

    def showEvent(self, event):
        super().showEvent(event)
        self.loadParamData()

    def get_selected_saved_param_id(self):
        item = self.ui.listWidget.currentItem()
        if item:
            content = item.text()
            saved_time_point_id = content.split(",")[0].split(":")[1].strip()
            return int(saved_time_point_id)
        return None

    def on_param_click(self):
        try:
            saved_time_point_id = self.get_selected_saved_param_id()
            if saved_time_point_id:
                menu = QMenu(self)
                start_action = menu.addAction("Запустить")
                delete_action = menu.addAction("Удалить")
                font = QFont()
                font.setPointSize(20)

                delete_action.setFont(font)
                start_action.setFont(font)

                action = menu.exec(QCursor.pos())

                dialog = QDialog(self)

                if action == delete_action:
                    self.handle_delete(dialog, saved_time_point_id)
                elif action == start_action:
                    self.handle_start(dialog, saved_time_point_id)

        except Exception as e:
            print("An error occurred:", e)

    def handle_delete(self, dialog, saved_time_point_id):
        try:
            success = self.delete_params(saved_time_point_id)

            if success:
                info_box = QMessageBox(self)
                info_box.setWindowTitle("Успех")
                info_box.setText("Параметры успешно удалены.")

                font = info_box.font()
                font.setPointSize(25)
                info_box.setFont(font)
                info_box.setStyleSheet(self.ui.get_message_box_delete_info())
                info_box.exec()

        except Exception as e:
            print("An error occurred:", e)

    def delete_params(self, id):
        message_box = QMessageBox(self)
        message_box.setWindowTitle('Удаление сохраненных параметров')
        message_box.setText('Вы уверены, что хотите удалить выбранные параметры?')
        message_box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        message_box.setDefaultButton(QMessageBox.StandardButton.No)
        message_box.setStyleSheet('color: black; background-color: white ;')
        font = message_box.font()
        font.setPointSize(20)
        message_box.setFont(font)
        button_font = QPushButton(self)
        font = button_font.font()
        font.setPointSize(15)
        button_font.setFont(font)
        message_box.setStyleSheet(self.ui.get_message_box_delete_true())
        reply = message_box.exec()

        if reply == QMessageBox.StandardButton.Yes:
            connect = sqlite3.connect('otbor.db')
            cursor = connect.cursor()

            try:
                cursor.execute('DELETE FROM time_points WHERE id = ?', (id,))
                connect.commit()
            except Exception as e:
                print(f"An error occurred: {e}")
            finally:
                connect.close()

            self.loadParamData()

    def handle_start(self, dialog, saved_time_point_id):
        message_box = QMessageBox(self)
        message_box.setWindowTitle('Запуск процесса')
        message_box.setText('Вы уверены, что хотите начать процесс с выбранными параметрами?')
        message_box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        message_box.setDefaultButton(QMessageBox.StandardButton.Yes)
        message_box.setStyleSheet(self.ui.get_message_box_style())
        reply = message_box.exec()

        if reply == QMessageBox.StandardButton.Yes:
            try:
                self.save_params_to_file(saved_time_point_id)
                self.start_params()
                self.open_bany()
                info_box = QMessageBox(self)
                info_box.setWindowTitle("Успех")
                info_box.setText("Процесс успешно запущен")

                font = info_box.font()
                font.setPointSize(18)
                info_box.setFont(font)

                message_box.setStyleSheet(self.ui.get_message_box_true())
                info_box.exec()

            except Exception as e:
                error_box = QMessageBox(self)
                error_box.setWindowTitle("Ошибка")
                error_box.setText(f"Не удалось запустить процесс: {e}")

                font.setPointSize(18)
                error_box.setFont(font)
                error_box.setStyleSheet(self.ui.get_message_box_false())
                error_box.exec()

            dialog.accept()

    def loadParamData(self):
        connection = sqlite3.connect('otbor.db')
        cursor = connection.cursor()

        cursor.execute('''
            SELECT time_points.id, time_points.one_point, time_points.two_point, 
            time_points.three_point, time_points.four_point, time_points.five_point, time_points.six_point, time_points.seven_point,
            time_points.eight_point, time_points.nine_point, time_points.ten_point
            FROM time_points

        ''')
        params = cursor.fetchall()
        connection.close()
        self.ui.listWidget.clear()

        for param in params:
            param_info = (
                f"Param ID: {param[0]},\n"
                f"Time_points: {param[1]}, {param[2]}, {param[3]}, {param[4]}, {param[5]}, {param[6]}, {param[7]}, {param[8]}, {param[9]}, {param[10]}"
            )
            self.ui.listWidget.addItem(QListWidgetItem(param_info))

    def save_params_to_file(self, id):
        connection = sqlite3.connect('otbor.db')
        cursor = connection.cursor()

        cursor.execute('''
            SELECT time_points.one_point, time_points.two_point, 
            time_points.three_point, time_points.four_point, time_points.five_point, time_points.six_point, time_points.seven_point,
            time_points.eight_point, time_points.nine_point, time_points.ten_point
            FROM time_points
            WHERE time_points.id = ?;
        ''', (id,))
        param = cursor.fetchone()
        connection.close()

        if param:
            with open("saved_parameters.txt", "w") as file:
                file.write("\n".join(map(str, param)))

    def start_params(self):

        threading.Thread(target=self.main_app.launch_script, args=[
            "main_start_otbor_with_k_l2.py"]).start() #скрипт запуска отборочных моторов на первой плате

    def open_bany(self):
        self.main_app.stack.setCurrentIndex(3)

    def open_start_menu(self):
        self.main_app.stack.setCurrentIndex(0)
