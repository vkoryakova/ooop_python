import sqlite3

connect = sqlite3.connect('otbor.db')
cursor = connect.cursor()

cursor.execute('''
    create table if not exists time_points(
        id integer primary key autoincrement,
        one_point int not null,
        two_point int not null,
        three_point int not null,
        four_point int not null,
        five_point int not null,
        six_point int not null,
        seven_point int not null,
        eight_point int not null,
        nine_point int not null,
        ten_point int not null

    )
''')

#cursor.execute("INSERT INTO time_points(id, one_point, two_point, three_point, four_point, five_point, six_point, seven_point) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", (1, 1, 2, 3, 4, 5, 6, 7), )
# cursor.execute('''drop table time_points''')
connect.commit()
connect.close()