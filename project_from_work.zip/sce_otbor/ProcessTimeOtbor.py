from PyQt6.QtWidgets import QMainWindow, QLabel
from PyQt6.QtCore import QTimer
from process_otbor import Ui_Form
import time
import threading

class ProcessOtbor(QMainWindow):
    def __init__(self, main_app):
        super().__init__()
        self.main_app = main_app
        self.ui = Ui_Form()
        self.ui.setupUi(self)
        self.ui.pushButton_back.clicked.connect(self.open_load_parameters)
        self.ui.pushButton_back_2.clicked.connect(self.stop)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_timer)
        self.trigger_times = []

        self.start_time = None

    def load_trigger_times(self):
        try:
            with open('saved_parameters.txt', 'r') as file:
                lines = file.readlines()
                self.trigger_times = [int(line.strip()) * 60 for line in lines]
        except Exception as e:
            print("Ошибка при чтении файла:", e)

    def open_load_parameters(self):
        # self.stop()
        self.main_app.stack.setCurrentIndex(1)

    def showEvent(self, event):
        super().showEvent(event)
        self.stop()
        self.load_trigger_times()
        if self.trigger_times:
            self.start_time = time.time()
            self.timer.start(1000)

    def update_timer(self):
        if not self.trigger_times:
            self.stop()
            return

        current_time = time.time()
        elapsed_time = int(current_time - self.start_time)

        while self.trigger_times and elapsed_time >= self.trigger_times[0]:
            self.trigger_times.pop(0)

        if self.trigger_times:
            remaining_seconds = self.trigger_times[0] - elapsed_time
            self.ui.label_3.setText(self.format_time(remaining_seconds))
        else:
            self.stop()

    def stop(self):
        self.timer.stop()
        self.trigger_times = []
        self.ui.label_3.setText("")
        threading.Thread(target=self.main_app.launch_script, args=[
            "ssh_bath_shotdown.py"]).start() #скрипт на второй плате, обращаемся к нему с помщью ssh

    def format_time(self, seconds):
        minutes = seconds // 60
        seconds = seconds % 60
        return f"До след точки: {minutes:02}:{seconds:02}"
