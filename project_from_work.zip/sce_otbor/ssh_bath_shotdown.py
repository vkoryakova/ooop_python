import paramiko

pi2_ip = '192.168.1.41'
pi2_username = 'professional'
pi2_password = 'pi'

python_script_path = '/home/professional/frt/bath_shotdown.py'  

def run_python_script():
    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh_client.connect(pi2_ip, username=pi2_username, password=pi2_password)

    command = f'python3 {python_script_path}'
    stdin, stdout, stderr = ssh_client.exec_command(command)

    print(stdout.read().decode())
    print(stderr.read().decode())

    ssh_client.close()
    print(f'launch {python_script_path} complete in {pi2_ip}.')

if __name__ == "__main__":
    run_python_script()