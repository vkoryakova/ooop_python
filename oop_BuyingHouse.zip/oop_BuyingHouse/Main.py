from Human import Human

from SmallHouse import SmallHouse

Human.default_info()
human1 = Human()
human1.info()

small_house = SmallHouse()
human1.buy_house(small_house)
human1.earn_money(100000)
human1.buy_house(small_house)
human1.info()