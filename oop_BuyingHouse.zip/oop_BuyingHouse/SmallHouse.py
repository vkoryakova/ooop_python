from House import House

class SmallHouse(House):
    def __init__(self):
        super().__init__(40)

    def __str__(self):
        return f"{self.area} метров"

