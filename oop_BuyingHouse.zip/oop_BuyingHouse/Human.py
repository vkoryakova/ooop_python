class Human():
    default_name = 'Виктория'
    default_age = 19

    def __init__(self, name=default_name, age=default_age, money=0, house=0):
        self.name = name
        self.age = age
        self.__money = money
        self.__house = house

    def info(self):
        print(f"Имя: {self.name}, Возраст: {self.age}, Деньги: {self.__money} "
              f"Дом: {self.__house}")

    @staticmethod
    def default_info():
        print(f"Имя по умолчанию: {Human.default_name}, Возраст по умолчанию: {Human.default_age}")

    def __make_deal(self, house):
        self.__money = self.__money - house._price
        self.__house = house

    def earn_money(self, ink_money):
        self.__money = self.__money + ink_money

    def buy_house(self, house):
        if house._price <= self.__money:
            self.__make_deal(house)
            print("Поздравляем Вас с приобретением дома!")
        else:
            print("На Вашем счету недостаточно средств!")
