class House:
    def __init__(self, area, price=1500):
        self._area = area
        self._price = price

    @property
    def area(self):
        return self._area

    @property
    def price(self):
        return self._price

    @area.setter
    def area(self, znach):
        if znach <= 0:
            print("Площадь должна быть больше 0")
        else:
            self._area = znach

    @price.setter
    def price(self, znach):
        if znach <= 0:
            print("Стоимость должна быть больше 0")
        else:
            self._price = znach


    def final_price(self, sales=0):
        return (self._price * (100 - sales)) / 100
