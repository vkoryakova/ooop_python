class BankAccount:
    def __init__(self, account_number, balance):
        self.account_number = account_number
        self.balance = balance

    def add(self, amount):
        self.balance += amount
        print(f"На счет {self.account_number} добавлено {amount}.\nТекущий баланс: {self.balance}")

    def withdraw(self, amount):
        if amount <= self.balance:
            self.balance -= amount
            print(f"С суммы {self.account_number} снято {amount}.\nТекущий баланс: {self.balance}")
        else:
            print(f"Недостаточно средств на счете {self.account_number}.")


acc1 = BankAccount("12345678", 500)
acc2 = BankAccount("87654321", 1000)

acc1.add(200)
acc1.withdraw(100)
acc1.withdraw(700)

acc2.add(500)
acc2.withdraw(300)
acc2.withdraw(1500)
