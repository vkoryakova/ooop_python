class Rectangle:
    def __init__(self, width, length):
        self.width = width
        self.length = length

    def area(self):
        return self.width * self.length

    def perimeter(self):
        return (self.length + self.width) * 2

rect1 = Rectangle(3, 6)
rect2 = Rectangle(7, 8)

print(f"Ширина = {rect1.width}, длинна = {rect1.length}\n"
      f"Площадь = {rect1.area()}, Периметр = {rect1.perimeter()}\n")

print(f"Ширина = {rect2.width}, длинна = {rect2.length}\n"
      f"Площадь = {rect2.area()}, Периметр = {rect2.perimeter()}")