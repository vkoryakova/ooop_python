from TomatoBush import TomatoBush
from Gardener import Gardener

Gardener.knowledge_base()
tomato = TomatoBush(10)
gard = Gardener("Viktoriya",tomato)
gard.work()
gard.work()
gard.harvest()
gard.work()
gard.work()
gard.harvest()
print(tomato.tomatoes)