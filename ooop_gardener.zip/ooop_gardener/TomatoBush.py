from Tomato import Tomato
class TomatoBush:
    def __init__(self, lis):
        list = []
        for i in range(lis):
            tomato1 = Tomato(i)
            list.append(tomato1)
        self.tomatoes = list

    def grow_all(self):
        if self.all_are_ripe() == True:
            print("Все помидоры созрели")
        else:
            for i in self.tomatoes:
                i.grow()
            print("Хорошо поработали!")

    def all_are_ripe(self):
        res = True
        for i in self.tomatoes:
            if i.is_ripe() == 0:
                res = False
                break

        return res

    def give_away_all(self):
        self.tomatoes = []