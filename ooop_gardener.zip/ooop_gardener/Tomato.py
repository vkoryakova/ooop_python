class Tomato:
    states = ["Отсутствует", "Цветение", "Зеленый", "Красный"]
    def __init__(self, id):
        self._index = id
        self._state = Tomato.states[0]
    def grow(self):
        if self._state == Tomato.states[-1]:
            pass
        else:
            id = Tomato.states.index(self._state)
            self._state = Tomato.states[id + 1]

    def is_ripe(self):
        if self._state == Tomato.states[-1]:
            return 1
        else:
            return 0