from TomatoBush import TomatoBush

class Gardener:
    def __init__(self, name, plant):
        self.name = name
        self._plant = plant



    @property
    def plant(self):
        return  self._plant

    @plant.setter
    def plant(self, value):
        if type(value) == TomatoBush:
            self._plant = value
        else:
            print("Error")

    def work(self):
        self._plant.grow_all()

    def harvest(self):
        if self._plant.all_are_ripe() == True:
            self._plant.give_away_all()
            print("Урожай собран")
        else:
            print("Урожай еще не созрел")

    @staticmethod
    def knowledge_base():
        print("Садоводство - это полезное и интересное занятие")