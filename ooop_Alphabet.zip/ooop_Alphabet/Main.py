from EngAlphabet import EngAlphabet
from Alphabet import Alphabet

en_alphabet = EngAlphabet()
en_alphabet.print()

print(en_alphabet.letters_num())

en_alphabet.is_en_letter('F')
en_alphabet.is_en_letter('Щ')
en_alphabet.example()

EngAlphabet.example()