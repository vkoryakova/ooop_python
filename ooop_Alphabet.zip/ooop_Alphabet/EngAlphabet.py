from string import ascii_uppercase
from Alphabet import Alphabet

class EngAlphabet(Alphabet):
    def __init__(self):
        super().__init__('En', list(ascii_uppercase))
    __letters_num = 26

    def is_en_letter(self, letter):
        res = "Такой буквы нет в данном алфавите"
        if(letter in self._letters) or (letter.upper() in self._letters):
            res = 'Такая буквае есть в алфавите'
        print(res)

    def letters_num(self):
        return self.__letters_num

    @staticmethod
    def example():
        print("I'm Vika, I like drawing and reading, but i don't have time")
