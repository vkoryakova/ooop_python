class Alphabet:
    def __init__(self, lang, letters=[]):
        self._lang = lang
        self._letters = letters

    @property
    def lang(self):
        return self._lang

    @property
    def letters(self):
        return self._letters

    @lang.setter
    def lang(self, znach):
        self._lang = znach

    def print(self):
        for i in self._letters:
            print(i)

    def letters_num(self):
        return len(self._letters)